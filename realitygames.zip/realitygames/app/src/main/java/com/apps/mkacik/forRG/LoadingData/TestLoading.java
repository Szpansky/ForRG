package com.apps.mkacik.forRG.LoadingData;

import android.os.Handler;

import com.apps.mkacik.forRG.DataModel.LaunchpadModel;
import com.apps.mkacik.forRG.DataModel.LocationModel;
import com.apps.mkacik.forRG.Throwable.ConnectionException;

import java.util.ArrayList;
import java.util.List;

public class TestLoading extends BaseLoading {

    @Override
    public void loadData(final ListCallBack listCallBack) {
        super.loadData(listCallBack);

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {

            @Override
            public void run() {
                LocationModel locationModel = new LocationModel("Vandenberg Air Force Base", "California", 34.632093, -120.610829);

                List<LaunchpadModel> launchpadList = new ArrayList<>();
                launchpadList.add(new LaunchpadModel(-1, "active", locationModel));
                launchpadList.add(new LaunchpadModel(0, "active", locationModel));
                launchpadList.add(new LaunchpadModel(1, "active", locationModel));
                launchpadList.add(new LaunchpadModel(2, "active", locationModel));
                launchpadList.add(new LaunchpadModel(3, "active", locationModel));
                launchpadList.add(new LaunchpadModel(4, "retired", locationModel));
                launchpadList.add(new LaunchpadModel(5, "active", locationModel));
                launchpadList.add(new LaunchpadModel(6, "active", locationModel));
                launchpadList.add(new LaunchpadModel(7, "retired", locationModel));
                launchpadList.add(new LaunchpadModel(8, "active", locationModel));
                launchpadList.add(new LaunchpadModel(9, "active", locationModel));
                launchpadList.add(new LaunchpadModel(10, "active", locationModel));
                launchpadList.add(new LaunchpadModel(11, "active", locationModel));
                launchpadList.add(new LaunchpadModel(12, "active", locationModel));
                launchpadList.add(new LaunchpadModel(13, "active", locationModel));
                launchpadList.add(new LaunchpadModel(14, "active", locationModel));
                launchpadList.add(new LaunchpadModel(15, "retired", locationModel));
                launchpadList.add(new LaunchpadModel(16, "active", locationModel));
                launchpadList.add(new LaunchpadModel(17, "active", locationModel));
                launchpadList.add(new LaunchpadModel(18, "active", locationModel));
                launchpadList.add(new LaunchpadModel(19, "active", locationModel));
                launchpadList.add(new LaunchpadModel(20, "active", locationModel));
                launchpadList.add(new LaunchpadModel(21, "active", locationModel));

                int random = (int) (Math.random() * 100);

                if (random % 2 == 0) {
                    listCallBack.onSuccess(launchpadList);
                } else {
                    listCallBack.onFail(new ConnectionException(ConnectionException.DOWNLOAD_DATA_ERROR + this.getClass()));
                }
                listCallBack.onFinally();

            }
        }, 1000);
    }

}
