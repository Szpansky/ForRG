package com.apps.mkacik.forRG.App;

public class Constants {

    public static final String siteURL = "https://api.spacexdata.com/";
}
