package com.apps.mkacik.forRG.LaunchPadDetails;

import android.arch.lifecycle.ViewModel;
import android.support.v4.app.FragmentManager;

import com.apps.mkacik.forRG.DataModel.LaunchPadModelDetail;

class LaunchPadDetailViewModel extends ViewModel {

    private LaunchPadModelDetail launchPadModelDetail;
    private FragmentManager fragmentManager;

    LaunchPadModelDetail getLaunchPadModelDetail() {
        return launchPadModelDetail;
    }

    void setLaunchPadModelDetail(LaunchPadModelDetail launchPadModelDetail) {
        this.launchPadModelDetail = launchPadModelDetail;
    }

    FragmentManager getFragmentManager() {
        return fragmentManager;
    }

    void setFragmentManager(FragmentManager fragmentManager) {
        this.fragmentManager = fragmentManager;
    }
}
